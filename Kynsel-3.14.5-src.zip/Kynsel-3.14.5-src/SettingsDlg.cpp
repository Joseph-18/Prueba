/* 
 * Copyright (C) 2011-2016 MicroSIP (http://www.microsip.org)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include "StdAfx.h"
#include "SettingsDlg.h"
#include "mainDlg.h"
#include "settings.h"
#include "Preview.h"
#include "langpack.h"

static BOOL prev;

SettingsDlg::SettingsDlg(CWnd* pParent /*=NULL*/)
: CDialog(SettingsDlg::IDD, pParent)
{
	Create (IDD, pParent);
	prev = FALSE;
}

SettingsDlg::~SettingsDlg(void)
{
	mainDlg->settingsDlg = NULL;
}

int SettingsDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (langPack.rtl) {
		ModifyStyleEx(0,WS_EX_LAYOUTRTL);
	}
	return 0;
}

BOOL SettingsDlg::OnInitDialog()
{
	CComboBox *combobox;
	CComboBox *combobox2;
	unsigned count;
	int i;

	CDialog::OnInitDialog();

	TranslateDialog(this->m_hWnd);
	combobox= (CComboBox*)GetDlgItem(IDC_AUTO_ANSWER);
	combobox->AddString(Translate(_T("No")));
	combobox->AddString(Translate(_T("All calls")));
	combobox->SetCurSel(accountSettings.autoAnswer);

	combobox= (CComboBox*)GetDlgItem(IDC_DENY_INCOMING);
	combobox->AddString(Translate(_T("No")));
	combobox->AddString(Translate(_T("All calls")));
	if (accountSettings.denyIncoming==_T("all"))
	{
		i=1;
	} else
	{
		i=0;
	}
	combobox->SetCurSel(i);

	((CButton*)GetDlgItem(IDC_LOCAL_DTMF))->SetCheck(accountSettings.localDTMF);
	((CButton*)GetDlgItem(IDC_ANSWER_BOX_RANDOM))->SetCheck(accountSettings.randomAnswerBox);
	((CButton*)GetDlgItem(IDC_VAD))->SetCheck(accountSettings.vad);
	((CButton*)GetDlgItem(IDC_EC))->SetCheck(accountSettings.ec);
	((CButton*)GetDlgItem(IDC_FORCE_CODEC))->SetCheck(accountSettings.forceCodec);

	GetDlgItem(IDC_RINGING_SOUND)->SetWindowText(accountSettings.ringingSound);

	pjmedia_aud_dev_info aud_dev_info[128];
	count = 128;
	pjsua_enum_aud_devs(aud_dev_info, &count);

	combobox= (CComboBox*)GetDlgItem(IDC_MICROPHONE);
	combobox->AddString(Translate(_T("Default")));
	combobox->SetCurSel(0);

	for (unsigned i=0;i<count;i++)
	{
		if (aud_dev_info[i].input_count) {
			CString audDevName(aud_dev_info[i].name);
			combobox->AddString( audDevName );
			if (!accountSettings.audioInputDevice.Compare(audDevName))
			{
				combobox->SetCurSel(combobox->GetCount()-1);
			}
		}
	}
	combobox= (CComboBox*)GetDlgItem(IDC_SPEAKERS);
	combobox->AddString(Translate(_T("Default")));
	combobox->SetCurSel(0);
	combobox2= (CComboBox*)GetDlgItem(IDC_RING);
	combobox2->AddString(Translate(_T("Default")));
	combobox2->SetCurSel(0);
	for (unsigned i=0;i<count;i++)
	{
		if (aud_dev_info[i].output_count) {
			CString audDevName(aud_dev_info[i].name);
			combobox->AddString(audDevName);
			combobox2->AddString(audDevName);
			if (!accountSettings.audioOutputDevice.Compare(audDevName))
			{
				combobox->SetCurSel(combobox->GetCount()-1);
			}
			if (!accountSettings.audioRingDevice.Compare(audDevName))
			{
				combobox2->SetCurSel(combobox->GetCount()-1);
			}
		}
	}

	pjsua_codec_info codec_info[64];

#ifdef _GLOBAL_VIDEO
	((CButton*)GetDlgItem(IDC_DISABLE_H264))->SetCheck(accountSettings.disableH264);
 	((CButton*)GetDlgItem(IDC_DISABLE_H263))->SetCheck(accountSettings.disableH263);
 	((CButton*)GetDlgItem(IDC_DISABLE_VP8))->SetCheck(accountSettings.disableVP8);
	if (accountSettings.bitrateH264.IsEmpty()) {
		const pj_str_t codec_id = {"H264", 4};
		pjmedia_vid_codec_param param;
		pjsua_vid_codec_get_param(&codec_id, &param);
		accountSettings.bitrateH264.Format(_T("%d"),param.enc_fmt.det.vid.max_bps/1000);
	}
	if (accountSettings.bitrateH263.IsEmpty()) {
		const pj_str_t codec_id = {"H263", 4};
		pjmedia_vid_codec_param param;
		pjsua_vid_codec_get_param(&codec_id, &param);
		accountSettings.bitrateH263.Format(_T("%d"),param.enc_fmt.det.vid.max_bps/1000);
	}
	if (accountSettings.bitrateVP8.IsEmpty()) {
		const pj_str_t codec_id = {"VP8", 4};
		pjmedia_vid_codec_param param;
		pjsua_vid_codec_get_param(&codec_id, &param);
		accountSettings.bitrateVP8.Format(_T("%d"),param.enc_fmt.det.vid.max_bps/1000);
	}
	GetDlgItem(IDC_BITRATE_264)->SetWindowText(accountSettings.bitrateH264);
	GetDlgItem(IDC_BITRATE_263)->SetWindowText(accountSettings.bitrateH263);
	GetDlgItem(IDC_BITRATE_VP8)->SetWindowText(accountSettings.bitrateVP8);

	combobox= (CComboBox*)GetDlgItem(IDC_VID_CAP_DEV);
	combobox->AddString(Translate(_T("Default")));
	combobox->SetCurSel(0);
	pjmedia_vid_dev_info vid_dev_info[64];
	count = 64;
	pjsua_vid_enum_devs(vid_dev_info, &count);
	for (unsigned i=0;i<count;i++)
	{
		if (vid_dev_info[i].fmt_cnt && (vid_dev_info[i].dir==PJMEDIA_DIR_ENCODING || vid_dev_info[i].dir==PJMEDIA_DIR_ENCODING_DECODING))
		{
			CString vidDevName(vid_dev_info[i].name);
			combobox->AddString(vidDevName);
			if (!accountSettings.videoCaptureDevice.Compare(vidDevName))
			{
				combobox->SetCurSel(combobox->GetCount()-1);
			}
		}
	}

	combobox= (CComboBox*)GetDlgItem(IDC_VIDEO_CODEC);
	combobox->AddString(Translate(_T("Default")));
	combobox->SetCurSel(0);
	count = 64;
	pjsua_vid_enum_codecs(codec_info, &count);
	for (unsigned i=0;i<count;i++)
	{
		combobox->AddString(PjToStr(&codec_info[i].codec_id));
		if (!accountSettings.videoCodec.Compare(PjToStr(&codec_info[i].codec_id)))
		{
			combobox->SetCurSel(combobox->GetCount()-1);
		}
	}
#endif

	return TRUE;
}

void SettingsDlg::PostNcDestroy()
{
	CDialog::PostNcDestroy();
	delete this;
}

BEGIN_MESSAGE_MAP(SettingsDlg, CDialog)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDCANCEL, &SettingsDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, &SettingsDlg::OnBnClickedOk)
#ifdef _GLOBAL_VIDEO
	ON_BN_CLICKED(IDC_PREVIEW, &SettingsDlg::OnBnClickedPreview)
#endif
	ON_BN_CLICKED(IDC_BROWSE, &SettingsDlg::OnBnClickedBrowse)
	ON_EN_CHANGE(IDC_RINGING_SOUND, &SettingsDlg::OnEnChangeRingingSound)
	ON_BN_CLICKED(IDC_DEFAULT, &SettingsDlg::OnBnClickedDefault)
END_MESSAGE_MAP()


void SettingsDlg::OnClose() 
{
	DestroyWindow();
}

void SettingsDlg::OnBnClickedCancel()
{
	OnClose();
}

void SettingsDlg::OnBnClickedOk()
{
	this->ShowWindow(SW_HIDE);
	mainDlg->PJDestroy();

	CComboBox *combobox;
	int i;
	combobox= (CComboBox*)GetDlgItem(IDC_AUTO_ANSWER);
	accountSettings.autoAnswer = combobox->GetCurSel();

	combobox= (CComboBox*)GetDlgItem(IDC_DENY_INCOMING);
	i = combobox->GetCurSel();
	accountSettings.denyIncoming=i?_T("all"):_T("");

	accountSettings.localDTMF=((CButton*)GetDlgItem(IDC_LOCAL_DTMF))->GetCheck();
	accountSettings.randomAnswerBox=((CButton*)GetDlgItem(IDC_ANSWER_BOX_RANDOM))->GetCheck();
	accountSettings.vad=((CButton*)GetDlgItem(IDC_VAD))->GetCheck();
	accountSettings.ec=((CButton*)GetDlgItem(IDC_EC))->GetCheck();
	accountSettings.forceCodec =((CButton*)GetDlgItem(IDC_FORCE_CODEC))->GetCheck();

	GetDlgItem(IDC_MICROPHONE)->GetWindowText(accountSettings.audioInputDevice);
	if (accountSettings.audioInputDevice==Translate(_T("Default")))
	{
		accountSettings.audioInputDevice = _T("");
	}

	GetDlgItem(IDC_SPEAKERS)->GetWindowText(accountSettings.audioOutputDevice);
	if (accountSettings.audioOutputDevice==Translate(_T("Default")))
	{
		accountSettings.audioOutputDevice = _T("");
	}

	GetDlgItem(IDC_RING)->GetWindowText(accountSettings.audioRingDevice);
	if (accountSettings.audioRingDevice==Translate(_T("Default")))
	{
		accountSettings.audioRingDevice = _T("");
	}

#ifdef _GLOBAL_VIDEO
	accountSettings.disableH264=((CButton*)GetDlgItem(IDC_DISABLE_H264))->GetCheck();
	accountSettings.disableH263=((CButton*)GetDlgItem(IDC_DISABLE_H263))->GetCheck();
	accountSettings.disableVP8=((CButton*)GetDlgItem(IDC_DISABLE_VP8))->GetCheck();
	GetDlgItem(IDC_BITRATE_VP8)->GetWindowText(accountSettings.bitrateVP8);
	if (!atoi(CStringA(accountSettings.bitrateH264))) {
		accountSettings.bitrateH264=_T("");
	}
	GetDlgItem(IDC_BITRATE_263)->GetWindowText(accountSettings.bitrateH263);
	if (!atoi(CStringA(accountSettings.bitrateH263))) {
		accountSettings.bitrateH263=_T("");
	}
	GetDlgItem(IDC_BITRATE_VP8)->GetWindowText(accountSettings.bitrateVP8);
	if (!atoi(CStringA(accountSettings.bitrateVP8))) {
		accountSettings.bitrateVP8=_T("");
	}
	GetDlgItem(IDC_VID_CAP_DEV)->GetWindowText(accountSettings.videoCaptureDevice);
	if (accountSettings.videoCaptureDevice==Translate(_T("Default")))
	{
		accountSettings.videoCaptureDevice = _T("");
	}

	GetDlgItem(IDC_VIDEO_CODEC)->GetWindowText(accountSettings.videoCodec);
	if (accountSettings.videoCodec==Translate(_T("Default")))
	{
		accountSettings.videoCodec = _T("");
	}
#endif

	GetDlgItem(IDC_RINGING_SOUND)->GetWindowText(accountSettings.ringingSound);

	accountSettings.SettingsSave();
	mainDlg->PJCreate();
	mainDlg->PJAccountAdd();

	OnClose();
}

void SettingsDlg::OnBnClickedBrowse()
{
	CFileDialog dlgFile( TRUE, _T("wav"), 0, OFN_NOCHANGEDIR, _T("WAV Files (*.wav)|*.wav|") );
	if (dlgFile.DoModal()==IDOK) {
		CString cwd;
		LPTSTR ptr = cwd.GetBuffer(MAX_PATH);
		::GetCurrentDirectory(MAX_PATH, ptr);
		cwd.ReleaseBuffer();
		if ( cwd.MakeLower() + _T("\\") + dlgFile.GetFileName().MakeLower() == dlgFile.GetPathName().MakeLower() ) {
			GetDlgItem(IDC_RINGING_SOUND)->SetWindowText(dlgFile.GetFileName());
		} else {
			GetDlgItem(IDC_RINGING_SOUND)->SetWindowText(dlgFile.GetPathName());
		}
	}
}

void SettingsDlg::OnEnChangeRingingSound()
{
	CString str;
	GetDlgItem(IDC_RINGING_SOUND)->GetWindowText(str);
	GetDlgItem(IDC_DEFAULT)->EnableWindow(str.GetLength()>0);
}

void SettingsDlg::OnBnClickedDefault()
{
	GetDlgItem(IDC_RINGING_SOUND)->SetWindowText(_T(""));
}

#ifdef _GLOBAL_VIDEO
void SettingsDlg::OnBnClickedPreview()
{
	CComboBox *combobox;
	combobox = (CComboBox*)GetDlgItem(IDC_VID_CAP_DEV);
	CString name;
	combobox->GetWindowText(name);
	if (!mainDlg->previewWin) {
		mainDlg->previewWin = new Preview(mainDlg);
	}
	mainDlg->previewWin->Start(mainDlg->VideoCaptureDeviceId(name));
}
#endif


